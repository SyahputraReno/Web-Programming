<?php 
class Pertemuan1 extends CI_Controller {
    public function index()
    {
        echo"<h1> Halo Perkenalkan </h1>";
        echo"Nama saya Reno Budi Syahputra <br>
        Saya tinggal di Bekasi, Tambun Selatan <br>
        Saat ini saya berkuliah di Bina Sarana Informatika dan Memasuki Semester 3 <br>
        Hobi saya adalah memotret"; 
    }
}

?>